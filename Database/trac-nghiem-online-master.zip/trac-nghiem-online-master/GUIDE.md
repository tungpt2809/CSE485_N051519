- Toàn bộ code trong thư mục resource
- Lưu ý: nên cho toàn bộ code trong thư mục resource ra thư mục gốc và chạy theo đường dẫn localhost hoặc domain.com, không nên đặt trong thư mục con và chạy localhost/resource hoặc domain.com/resource để tránh lỗi không nhận css.
- Chạy domain/install.php để tiến hành cài đặt và cấu hình hệ thống
- Sửa tài khoản gửi email quên mật khẩu tại /controllers/controller_login.php dòng 110 và 111
- Tài khoản mặc định
	tài khoản: admin	
	mật khẩu: 123456
- Để thử nghiệm hệ thống với bộ cơ sở dữ liệu cho sẵn, vui lòng import file tại /res/files/test_data.sql
+ tài khoản thử nghiệm học sinh: 
		tài khoản: 2017HS1 -> 2017HS23
		mật khẩu: 123456
+ tài khoản thử nghiệm giaovien: 
		tài khoản: giaovien
		mật khẩu: 123456
+ tài khoản thử nghiệm admin: 
		tài khoản: admin
		mật khẩu: 123456