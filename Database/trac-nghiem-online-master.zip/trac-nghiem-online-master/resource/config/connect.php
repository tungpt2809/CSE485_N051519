<?php
return (object) array('host' => '','user' => '','password' => '','dbname' => '','INSTALL_MODE' => TRUE);
?>