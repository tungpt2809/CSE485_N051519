	<div class="title-content">
		<span class="title">Liên Hệ</span>
	</div>
	<div class="content">
		<div class="container" style="text-align: center;"><br />
			<h5><i  id="about-title"></i></h5>
			<p>Phiên bản: <i id="about-version"><?=Config::VERSION?></i></p>
			<p>Release: <i id="about-release"><?=Config::RELEASE?></i></p>
			<p>Phát triển: <i id="about-owner"><?=Config::OWNER?></i></p>
			<p>Liên hệ: <i id="about-email"><?=Config::EMAIL?></i></p>
			<p><i id="about-copyright"><?=Config::COPYRIGHT?></i></p>
			<p>GitHub: <a href="https://github.com/meesudzu/trac-nghiem-online">https://github.com/meesudzu/trac-nghiem-online</a></p>
			<p>Credits: <a href="https://github.com/meesudzu/trac-nghiem-online/graphs/contributors">https://github.com/meesudzu/trac-nghiem-online/graphs/contributors</a></p>
		</div>
	</div>
</div>
