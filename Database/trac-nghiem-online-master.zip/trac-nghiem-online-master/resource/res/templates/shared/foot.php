<!-- <div class="col l12 footer footer-mini" id="footer">
	<div class="row reset-margin">
		<div class="col l6 s6">
			<i id="website-copyright"><?=Config::COPYRIGHT?></i>
		</div>
		<div class="col l6 s6 right-align">
			<i id="website-title"><?=Config::TITLE?></i>
		</div>
	</div>
</div> -->
</body>

</html>
